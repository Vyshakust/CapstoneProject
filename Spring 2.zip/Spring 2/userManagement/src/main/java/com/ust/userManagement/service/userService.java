package com.ust.userManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ust.userManagement.domain.User;
import com.ust.userManagement.repository.userRepository;

@Service
public class userService {
	
	@Autowired
	userRepository userRepo;
	
//	public User getUser(int userId) {
//		Optional<User> userExist = userRepo.findById(userId);
//		if(userExist.isPresent()) {
//			return userExist.get();
//		}
//		else {
//			return null;
//		}
//	}
	
	public Boolean userLogin(String uEm, String uPwd) {
		User u = userRepo.findByUserEmailAndUserPassword(uEm, uPwd);
		if(u!=null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public User addUser(User uNew) {
		User u = userRepo.save(uNew);
		return u;	
	}
	
	public User updUser(User userNew) {
		Optional<User> userExist = userRepo.findById(userNew.getUserId());
		if(userExist.isPresent()) {
			User userOld = userExist.get();
			userOld.setUserPassword(userNew.getUserPassword());
			userOld.setUserEmail(userNew.getUserEmail());
			userOld.setUserAddress(userNew.getUserAddress());
			userOld.setUserMobile(userNew.getUserMobile());
			return userOld;
		}
		else
			return null;
	}
	
	public Boolean delUser(int userId) {
		Optional<User> userExist= userRepo.findById(userId);
		if(userExist.isPresent()) {
			userRepo.deleteById(userId);
			return true;
		}
		else {
			return false;
		}
	}

	public List<User> getAll() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

}
