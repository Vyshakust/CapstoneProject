module StreamPractise {
}