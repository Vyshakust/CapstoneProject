package Streamforeach;

import java.util.Arrays;
import java.util.List;

public class PrintStringLengthGreaterThan3 {
	public static void main(String args[]) {
		List<String> l1=Arrays.asList("Hello","hi","Ram","Question","Interview");
		l1.stream().filter(n->n.length()>3).forEach(n->System.out.println(n));
	}

}
