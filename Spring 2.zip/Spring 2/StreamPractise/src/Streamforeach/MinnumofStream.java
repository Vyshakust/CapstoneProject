package Streamforeach;

import java.util.Arrays;
import java.util.List;

public class MinnumofStream {
	public static void main(String args[]) {
		List<Integer> l1=Arrays.asList(4,5,7,3,1);
		int n=l1.stream().min(Integer::compare).get();
		System.out.print(n);
	}

}
