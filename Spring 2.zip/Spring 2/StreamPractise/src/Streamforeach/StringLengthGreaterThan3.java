package Streamforeach;

import java.util.Arrays;
import java.util.List;

public class StringLengthGreaterThan3 {
	public static void main(String args[]) {
	List<String> l1 = Arrays.asList("Hello","Interview","Ram","hi","beautiful");
	long n=l1.stream().filter(str->str.length()>3).count();
	System.out.println(n);
	}

}
