package Streamforeach;

import java.util.ArrayList;
import java.util.List;

public class StreamForEach {
	public static void main(String args[] ){
		List<String> l1=new ArrayList<>();
		l1.add("Hello");
		l1.add("Interview");
		l1.add("Questions");
		l1.add("Answers");
		l1.stream().forEach(n->System.out.println(n));
		
	}

}
