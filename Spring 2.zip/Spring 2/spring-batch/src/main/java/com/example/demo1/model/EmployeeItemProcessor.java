package com.example.demo1.model;

import org.springframework.batch.item.ItemProcessor;

public class EmployeeItemProcessor implements ItemProcessor<Employee,Employee>{


	public Employee process(Employee employee) throws Exception{
		System.out.println("Employee Name"+employee.getEmpName());
		return employee;
	}
}
