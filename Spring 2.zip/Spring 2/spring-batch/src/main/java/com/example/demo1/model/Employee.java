package com.example.demo1.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {
	
	private String empId;
	private String empName;
	
	public String getEmpId() {
		return this.empId;
	}
	
	public void setEmpId(String empId) {
		this.empId=empId;
	}
	
	public String getEmpName() {
		return this.empName;
	}
	
	public void setEmpName(String empName) {
		this.empName=empName;
	}
}
