package com.example.demo1.model;

import org.springframework.batch.item.file.mapping.FieldSetMapper;

public class EmployeFieldSetMapper implements FieldSetMapper<Employee>{

		public Employee mapFieldSet(FieldSet fieldSet)throws BindException{
			Employee employee = new Employee();
			employee.setEmpId(fieldSet.readString(0));
			employee.setEmpId(fieldSet.readString(1));		
		}
}
