package classes;

public class Vehicle {
	
	int a;
	Car c;
	
	
	
	public void setc(Car c1) {
		c=c1;
	}
	
	public Car getc() {
		return c;
	}

}
