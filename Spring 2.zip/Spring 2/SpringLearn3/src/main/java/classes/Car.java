package classes;

public class Car {
	public Car() {
		System.out.println("This is car class");
	}
	
	public void  Start1() {
		System.out.println("car started");
	}

}
