package classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String args[]) {
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("NewFile.xml");
		
		Vehicle v=(Vehicle) context.getBean("vehicle");
		v.getc().Start1();
	}
}
