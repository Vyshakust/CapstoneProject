package com.ust.com.ticketbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ust.com.ticketbooking.model.Train;
import com.ust.com.ticketbooking.repository.TrainRepository;

@Service
public class TrainService {
	
	@Autowired
	TrainRepository tRepo;
    
	public List<Train> getAllTrain(){
		
		List<Train> ls= tRepo.findAll();
		return ls;
	}
	
	public Optional<Train> getByNumber(int num) {
		Optional<Train> t= tRepo.findById(num);
		return t;
		}
	public Optional<Train> updateByNumber(int num, Train t){
		
		Optional<Train> tr= tRepo.findById(num);
		if(tr.isPresent()) {
			  tr.get().setTrain_name(t.getTrain_name());
			  tr.get().setDeparture_station(t.getDeparture_station());
			  tr.get().setArrival_station(t.getArrival_station());
			  tr.get().setDeparture_time(t.getDeparture_time());
			  tr.get().setArrival_time(t.getArrival_time());
			  tRepo.save(tr.get());
			  return tr;
			 
		}
		else {
			return null;
		}
	
	}
	public Optional<Train> deleteByNum(int num){
		Optional<Train> t= tRepo.findById(num);
		if(t.isPresent()) {
			 tRepo.deleteById(num);
			 return t;
		}
		else {
			return null;
		}
	}
}
