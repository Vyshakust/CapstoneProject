package com.ust.com.ticketbooking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.com.ticketbooking.model.Train;

import com.ust.com.ticketbooking.service.TrainService;

@RestController

public class TrainController {
	
	@Autowired
	TrainService tService;
	@GetMapping("/trains")
	public ResponseEntity<List<Train>> getAllTrain(){
		
		List<Train> ls= tService.getAllTrain();
		return ResponseEntity.ok().body(ls);
	}
	@GetMapping("/trains/{num}")
	public ResponseEntity<Train> getTrainBynum(@PathVariable int num){
		Optional<Train> t= tService.getByNumber(num);
		if(t.isPresent()) {
			return ResponseEntity.ok().body(t.get());
		}
		else {
			return ResponseEntity.notFound().build();
					
		}
	}
	@PutMapping("/trains/{num}")
	public ResponseEntity<Train> updateTrainbyNum(@PathVariable int num, @RequestBody Train t){
		
		//Optional<Train> tr = tService.updateByNumber(num); 
		if(tService.updateByNumber(num, t).isPresent()) {
			return ResponseEntity.ok().body(tService.updateByNumber(num, t).get());
		}
		else {
			return ResponseEntity.notFound().build();
		}
			
	}
	@DeleteMapping("/trains/{num}")
	public ResponseEntity<Train> deleteTrainById(@PathVariable int num){
		
		if(tService.deleteByNum(num).isPresent()) {
			return ResponseEntity.ok().body(tService.deleteByNum(num).get());
		}
		else {
			return ResponseEntity.notFound().build();
		}
	}

}
