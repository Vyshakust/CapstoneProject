package com.example.ticketbooking.controller;

import java.time.LocalDate;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ticketbooking.entity.TicketManage;
import com.example.ticketbooking.service.TicketService;

@RestController
@RequestMapping("/ticket")
public class TicketController {
	
	@Autowired
	TicketService ticketService;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<TicketManage>> getAllTickets() {
		List<TicketManage> ls=ticketService.getTickets();
		return ResponseEntity.ok().body(ls);
		
	}
	
	@GetMapping("/get/{ticketId}")
	public ResponseEntity<Optional<TicketManage>> getTicketById(@PathVariable long ticketId){
		Optional<TicketManage> t=ticketService.getTicketById(ticketId);
		if(t.isEmpty()) {
		return ResponseEntity.notFound().build();
		}
		else
			return ResponseEntity.ok().body(t);
	}
	
	@PostMapping("/post")
	public ResponseEntity<TicketManage> createTicket(@RequestBody TicketManage ticket){
		ticketService.createTicket(ticket);
		return ResponseEntity.ok().build();
	}
	
	@PutMapping("/put/{ticketId}")
	public ResponseEntity<TicketManage> updateTicket(@RequestBody TicketManage ticket,@PathVariable long ticketId){
		ticketService.updateTicket(ticketId,ticket.getUserId(),ticket.getCategory(),ticket.getLuggageWeight(),ticket.getDestination(),ticket.getSource(),ticket.getArrivaldateTime(),ticket.getReachdateTime());
		return ResponseEntity.ok().build();
		
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<TicketManage> deleteById(@PathVariable long ticketId) {
		ticketService.deleteTicket(ticketId);
		return ResponseEntity.ok().build();
	}
	
	

}
