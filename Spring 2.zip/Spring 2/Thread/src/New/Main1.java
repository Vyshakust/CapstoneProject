package New;

class Mymethod{
	void display(String str) {
		for(int i=0;i<str.length();i++) {
			System.out.println(str.charAt(i));
		}
	}
}

class Mythread1 extends Thread{
	Mymethod m;
	Mythread1(Mymethod m){
		
	}
}


public class Main1 {
	

}
