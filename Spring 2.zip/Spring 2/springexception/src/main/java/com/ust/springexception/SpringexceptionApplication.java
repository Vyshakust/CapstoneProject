package com.ust.springexception;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringexceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringexceptionApplication.class, args);
	}

}
