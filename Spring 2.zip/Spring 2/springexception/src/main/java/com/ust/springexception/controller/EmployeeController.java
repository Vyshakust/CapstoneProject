package com.ust.springexception.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.springexception.entity.Employee;
import com.ust.springexception.exception.EmployeeNotFound;
import com.ust.springexception.reposiotry.EmployeeRepository;

@RestController
public class EmployeeController {

		@Autowired
		EmployeeRepository employeerepo;
		
		@GetMapping("/employee/{id}")
		public ResponseEntity<Employee> getEmployee(@PathVariable long id){
			Optional<Employee> e1=employeerepo.findById(id);
			if(e1.isPresent()) {
				return new ResponseEntity<>(e1.get(),HttpStatus.OK);
			}
			else {
				throw new EmployeeNotFound("Employee not found with id"+id);
			}
		}
		
		@ExceptionHandler(EmployeeNotFound.class)
		public ResponseEntity<Object> handleEmployeeNotFound(EmployeeNotFound ex){
			String message=ex.getMessage();
			return new ResponseEntity<>(message,HttpStatus.NOT_FOUND);
		}
		
		@PostMapping("/employee")
		public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
			Employee e1=employeerepo.save(employee);
			return new ResponseEntity<>(e1,HttpStatus.OK);
		}
}
