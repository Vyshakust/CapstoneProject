package com.ust.springexception;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringexceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
