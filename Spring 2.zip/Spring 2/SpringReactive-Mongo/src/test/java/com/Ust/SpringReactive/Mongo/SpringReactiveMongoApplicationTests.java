package com.Ust.SpringReactive.Mongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactiveMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
