package org.example.controller;
import org.example.domain.Comment;
import org.example.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/comments")
@CrossOrigin
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/create")
    public ResponseEntity<Comment> createComment(@RequestBody Comment comment){
        return ResponseEntity.ok().body(commentService.addComment(comment));
    }
    @GetMapping("/user/{id}")
    public Comment getUser(@PathVariable long id) {
        Comment user= commentService.findCommentById(id);
        return user;
    }
    @DeleteMapping("/user/{id}")
    public ResponseEntity<Comment> deleteUser(@PathVariable long id) {
        commentService.deleteUser(id);
        return new ResponseEntity<Comment>(HttpStatus.OK);
    }
    
    @GetMapping("/all/{id}")
    public ResponseEntity<List<Comment>> getAllComments(@PathVariable long id){
    	return new ResponseEntity<List<Comment>>(commentService.getCommentsByTaskId(id),HttpStatus.OK);
    }
    }




