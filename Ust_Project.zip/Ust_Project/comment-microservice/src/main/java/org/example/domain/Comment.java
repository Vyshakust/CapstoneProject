package org.example.domain;

import javax.persistence.*;

@Entity
@Table(name = "comments")
public class Comment {

    @Id
    private long commentId;
    private String description;
    private long taskId;

//    @OneToOne(cascade=CascadeType.ALL)
//    @JoinColumn(name="comment_id", referencedColumnName = "task_id")
//    private Task task;

    public Comment(){

    }

    public Comment(long commentId, String description, long taskId) {
        this.commentId = commentId;
        this.description = description;
        this.taskId = taskId;
    }

    public long getCommentId() {
        return commentId;
    }

    public String getDescription() {
        return description;
    }

    public void setCommentId(long commentId) {
        this.commentId = commentId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getTaskId() {
        return taskId;
    }

    public void setTaskId(long taskId) {
        this.taskId = taskId;
    }
}
