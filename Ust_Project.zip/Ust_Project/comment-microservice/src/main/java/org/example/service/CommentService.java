package org.example.service;

import org.example.domain.Comment;
import org.example.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommentService {
    @Autowired
    private CommentRepository commentRepository;


    public Comment addComment(Comment comment){
        return commentRepository.save(comment);
    }



    public void deleteUser(long id) {
        commentRepository.deleteById(id);
    }

    public Comment findCommentById(long id)
    {
        Optional<Comment> result = commentRepository.findById(id);
        Comment comment = result.get();
        return comment;
    }
    
    
    public List<Comment> getCommentsByTaskId(Long taskId) {
        return commentRepository.findByTaskId(taskId);
    }
    

	public List<Comment> getAll() {
		// TODO Auto-generated method stub
		return commentRepository.findAll();
	}
}
