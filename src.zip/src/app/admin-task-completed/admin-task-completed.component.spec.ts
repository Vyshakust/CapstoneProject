import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTaskCompletedComponent } from './admin-task-completed.component';

describe('AdminTaskCompletedComponent', () => {
  let component: AdminTaskCompletedComponent;
  let fixture: ComponentFixture<AdminTaskCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTaskCompletedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTaskCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
