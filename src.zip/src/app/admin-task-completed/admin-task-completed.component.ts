import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Task } from '../Task';

@Component({
  selector: 'app-admin-task-completed',
  templateUrl: './admin-task-completed.component.html',
  styleUrls: ['./admin-task-completed.component.css']
})
export class AdminTaskCompletedComponent {

  constructor(private service:ServiceService,private router:Router){
     
  }

  tasks:Task[]=[];
  task1:Task[]=[];
  completedTasks: Task[] = this.tasks.filter((task) => task.status == "completed");
  
  ngOnInit():void{
    
  this.service.getTaskList().subscribe(data =>{this.tasks=data;});
  console.log(this.tasks);
  this.task1=this.completedTask();
  console.log(this.completedTasks);
  }

  completedTask():Task[]{
   return this.completedTasks = this.tasks.filter((task) => task.status == "completed");
  }

  
  

}
