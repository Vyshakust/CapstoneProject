import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-view-updates',
  templateUrl: './admin-view-updates.component.html',
  styleUrls: ['./admin-view-updates.component.css']
})
export class AdminViewUpdatesComponent {

}
