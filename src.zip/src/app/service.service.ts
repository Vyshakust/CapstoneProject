import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Task } from './Task';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private baseURL="http://localhost:8084/admin";
  constructor(private httpclient:HttpClient) { }

  getTaskList():Observable<Task[]>{
    return this.httpclient.get<Task[]>(`${this.baseURL}`);
  }

  addTask(task:Task):Observable<Object>{
    return this.httpclient.post(`${this.baseURL}`,task);
  }
  
}
