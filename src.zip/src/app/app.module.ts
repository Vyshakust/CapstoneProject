import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminAddTaskComponent } from './admin-add-task/admin-add-task.component';
import { AdminViewUpdatesComponent } from './admin-view-updates/admin-view-updates.component';
import { AdminTaskCompletedComponent } from './admin-task-completed/admin-task-completed.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    SignInComponent,
    AdminHomeComponent,
    AdminAddTaskComponent,
    AdminViewUpdatesComponent,
    AdminTaskCompletedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
