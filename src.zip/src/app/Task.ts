export class Task {
     id:number=4;
	
	 taskname:string='';
	
	 comments:string='';
	
	 status:string='';
	
	 userid:string='';
  
    //  constructor(id:number,taskname:string,comments:string,status:string,userid:string){
    //      this.id=id;
    //      this.taskname=taskname;
    //      this.comments=comments;
    //      this.status=status;
    //      this.userid=userid;
    //  }
    }