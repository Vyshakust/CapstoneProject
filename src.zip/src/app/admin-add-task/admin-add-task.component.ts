import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Task } from '../Task';

@Component({
  selector: 'app-admin-add-task',
  templateUrl: './admin-add-task.component.html',
  styleUrls: ['./admin-add-task.component.css']
})
export class AdminAddTaskComponent {
  taskName:string='';
  selectedUser:string='';
  task:Task=new Task();

   userList: string[] = ["user1", "user2", "user3"];

   constructor(private service:ServiceService,private router:Router){
     

   }


   onSubmit(){
    //  console.log(this.task.taskname);
    //  console.log(this.task.userid);
    //console.log(this.task);
    this.saveTask();
   }

   saveTask(){
     this.task.id=13;
    //  this.task.status="check";
    //  this.task.comments="check";
     console.log(this.task);
     this.service.addTask(this.task).subscribe(data=>{
        console.log(data);
     },
     error=>console.log(error)
     
     );
   }

   goToAdminHome(){
    this.router.navigate(['/admin-home']);
   }
}
