import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddTaskComponent } from './admin-add-task.component';

describe('AdminAddTaskComponent', () => {
  let component: AdminAddTaskComponent;
  let fixture: ComponentFixture<AdminAddTaskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAddTaskComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminAddTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
