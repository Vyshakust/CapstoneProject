import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Task } from '../Task';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent {

  constructor(private router:Router,private myService:ServiceService){

  }
  
  tasks:Task[]=[];
  ngOnInit():void{
 
  this.myService.getTaskList().subscribe(data =>{this.tasks=data;});
  }

  addNewTask(){
    this.router.navigate(['/admin-home/admin-add-task']);
  }

}
