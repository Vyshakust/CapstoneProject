import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminAddTaskComponent } from './admin-add-task/admin-add-task.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminTaskCompletedComponent } from './admin-task-completed/admin-task-completed.component';
import { AdminViewUpdatesComponent } from './admin-view-updates/admin-view-updates.component';
import { SignInComponent } from './sign-in/sign-in.component';

const routes: Routes = [
  {path:'',redirectTo:'sign-in',pathMatch:'full'},
  {path:'sign-in',component:SignInComponent},
  {path:'admin-home',component:AdminHomeComponent},
  {path:'admin-home/admin-view-updates',component:AdminViewUpdatesComponent},
  {path:'admin-home/admin-task-completed',component:AdminTaskCompletedComponent},
  {path:'admin-home/sign-in',component:SignInComponent},
  {path:'admin-home/admin-add-task',component:AdminAddTaskComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
