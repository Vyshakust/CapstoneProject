package com.ressiliance.restresilliancebus.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ressiliance.restresilliancebus.model.Bus;
import com.ressiliance.restresilliancebus.service.BusService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;



@RestController
public class BusController {

	
	@Autowired
	private BusService busservice;
	

//	private static final String bService="DEPARTMENT.SERVICE";



	
	
	@GetMapping("/bus")
	public ResponseEntity<List<Bus>> getAllBus(){
		return new ResponseEntity<>(busservice.getAllBus(),HttpStatus.OK);
	}
	
	

	
	
	@GetMapping("/bus/vendor/{id}")
	@CircuitBreaker(name ="aaa", fallbackMethod = "fallbackMethod2")
	@RateLimiter(name="aaa")
	public ResponseEntity<Object> getVendor(@PathVariable long id){
		return new ResponseEntity<>(busservice.getFromVendor(id),HttpStatus.OK);
	}
	
	public ResponseEntity<?> fallbackMethod2(long id,Throwable throwable) {
		System.out.println("*************************fallback**********************************************");
		return  ResponseEntity.ok().body("waitt");
	}
	
	
	


	@GetMapping("/bus/{id}")
	public ResponseEntity<Bus> getBus(@PathVariable long id){
		Optional<Bus> v1=busservice.findBus(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping("/bus")
	public ResponseEntity<Bus> addVendor(@RequestBody Bus v1){
		return new ResponseEntity<>(busservice.addBus(v1),HttpStatus.OK);
	}
	
	
	@GetMapping("/bus/circuit")
//	@CircuitBreaker(name ="aaa", fallbackMethod = "fallbackMethod2")
//	@RateLimiter(name="aaa")
	public String get()
	{
		return "hai";
	}
	public String fallbackMethod2(Exception e)
	{
		return "Fallback";
	}
}
