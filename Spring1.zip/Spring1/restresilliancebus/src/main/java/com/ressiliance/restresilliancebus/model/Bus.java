package com.ressiliance.restresilliancebus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bus {
	@Id
	@Column(name="bus_id")
	private long id;
	
	@Column(name="bus_route")
	private String route;
	
	@Column(name="vendor_id")
	private long vendorid;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public long getVendorid() {
		return vendorid;
	}

	public void setVendorid(long vendorid) {
		this.vendorid = vendorid;
	}

	@Override
	public String toString() {
		return "Bus [id=" + id + ", route=" + route + ", vendorid=" + vendorid + "]";
	}
	
	
}
