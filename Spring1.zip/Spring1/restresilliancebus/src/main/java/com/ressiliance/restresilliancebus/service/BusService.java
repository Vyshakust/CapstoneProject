package com.ressiliance.restresilliancebus.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ressiliance.restresilliancebus.model.Bus;
import com.ressiliance.restresilliancebus.repo.Busrepo;


@Service
public class BusService {
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private Busrepo busrepo;
	
	public Object getFromVendor (long id) {
		Optional<Bus> b1=busrepo.findById(id);
		
		String url = "http://localhost:8082/vendors/"+b1.get().getVendorid();
//		ResponseEntity<Vendordto> response = restTemplate.getForEntity(url, Vendordto.class);
		ResponseEntity response = restTemplate.getForEntity(url, String.class);
//		Vendordto vendor=restTemplate.getForObject(url,Vendordto.class,id);
//		return vendor;
		if (response.getStatusCode() == HttpStatus.OK) {
	        return response.getBody();
	        } else {
	        // Handle error case
	        return null;
	    }
	}
	
	public List<Bus> getAllBus(){
		return busrepo.findAll();
	}
	
	public Optional<Bus> findBus(long id){
		Optional<Bus> v1=busrepo.findById(id);
		return v1;
	}
	
	public Bus addBus(Bus v) {
		Bus v1 = busrepo.save(v);
		return v1;
	}

}
