package com.ressiliance.restresilliancebus.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ressiliance.restresilliancebus.model.Bus;

public interface Busrepo extends JpaRepository<Bus, Long>{

}
