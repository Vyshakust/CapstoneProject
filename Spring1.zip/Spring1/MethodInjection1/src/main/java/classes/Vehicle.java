package classes;

public class Vehicle {
	Car c1;
	Bike b1;
	
	public Vehicle() {
		System.out.println("NewBrand");
	}
	
	public void first() {
		System.out.println("Vehicle is going to start");
		c1.startCar();
		b1.startBike();
	}
	
	public void setc1(Car c) {
		c1=c;
	}
	
	public Car getc1() {
		return c1;
	}
	
	public void setb1(Bike b) {
		b1=b;
	}
	
	public Bike getb1() {
		return b1;
	}
}
