package classes;

public class Car {
	public Car() {
		System.out.println("Car Constructor");
	}
	
	public void startCar() {
		System.out.println("Car Started");
	}

}
