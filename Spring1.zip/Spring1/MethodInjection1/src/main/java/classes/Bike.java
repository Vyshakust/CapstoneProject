package classes;

public class Bike {
	
	public Bike() {
		System.out.println("Bike Construcotr");
	}

	public void startBike() {
		System.out.println("Bike Started");
	}
	
	
}
