package classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String args[]) {
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("NewFile.xml");
	Vehicle v = context.getBean("Mah",Vehicle.class);
	
	v.getc1().startCar();
	}
}
