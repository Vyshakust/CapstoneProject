package com.ust.self1.service;

import java.util.List;
import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ust.self1.model.Task;
import com.ust.self1.repository.TaskRepository;

@Service
public class TaskService {

		@Autowired
		TaskRepository taskrepo;

		@Transactional
		public Task getTaskById(int id) {
			Task result = taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("jhg"));
			return result;
		}

		@Transactional
		public List<Task> getAllTasks() {
			List<Task> l1=taskrepo.findAll();
			return l1;
		}

		@Transactional
		public List<Task> addTask(List<Task> l2) {
			taskrepo.saveAll(l2);
			return l2;
		}

		@Transactional
		public void updatetask(int id, Task t1) {
			Task t=taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("no element"));
			t.setTaskname(t1.getTaskname());
		}
		
		
		
}
