package com.ust.self1.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringSecurityConfig {

	public InMemoryUserDetailsManager userDetails
		
}
