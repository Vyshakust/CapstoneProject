package com.ust.self1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Self1Application {

	public static void main(String[] args) {
		SpringApplication.run(Self1Application.class, args);
	}

}
