package com.ust.self1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="task1")
public class Task {

	@Id
	@Column(name="task_id")
	private int id;
	
	@Column(name="task_name")
	private String taskname;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTaskname() {
		return taskname;
	}

	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", taskname=" + taskname + "]";
	}
	
	
}
