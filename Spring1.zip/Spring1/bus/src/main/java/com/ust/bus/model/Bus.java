package com.ust.bus.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bus")
public class Bus {
	
	@Id
	@Column(name="bus_id")
	private long id;
	
	@Column(name="bus_route")
	private String route;
	
	@Column(name="bus_depTime")
	private LocalDateTime departureTime;
	
	@Column(name="bus_arrivalTime")
	private LocalDateTime arrivalTime;
	
	@Column(name="bus_duration")
	private double duration;
	
	@Column(name="vendor_id")
	private long vendorid;

	public long getVendorid() {
		return vendorid;
	}

	public void setVendorid(long vendorid) {
		this.vendorid = vendorid;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public LocalDateTime getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}

	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "Bus [id=" + id + ", route=" + route + ", departureTime=" + departureTime + ", arrivalTime="
				+ arrivalTime + ", duration=" + duration + ", vendorid=" + vendorid + "]";
	}
	
	
	
}
