package com.ust.bus.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.bus.dto.Vendordto;
import com.ust.bus.model.Bus;
import com.ust.bus.service.BusService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;


@RestController
public class BusController {
	@Autowired
	private BusService busservice;
	

//	private static final String bService="DEPARTMENT.SERVICE";



	
	
	@GetMapping("/bus")
	public ResponseEntity<List<Bus>> getAllBus(){
		return new ResponseEntity<>(busservice.getAllBus(),HttpStatus.OK);
	}
	
	
//	 @GetMapping("/bus/vendor/{id}")
//	    @CircuitBreaker(name = "vendorCircuitBreaker", fallbackMethod = "fallbackMethod")
//	    public ResponseEntity<Object> callVendorService(@PathVariable long id) {
//		 return new ResponseEntity<>(busservice.getFromVendor(id),HttpStatus.OK);
//	    }
//
//	    // Fallback method to be called when circuit breaker is open or a failure occurs
//	    public ResponseEntity<String> fallbackMethod(String vendorId, Throwable throwable) {
//	        // Handle the fallback logic, e.g., return a default response
//	        return ResponseEntity.ok("Vendor service is currently unavailable. Please try again later.");
//	    }
	
	
	@GetMapping("/bus/vendor/{id}")
	@CircuitBreaker(name ="bService", fallbackMethod = "fallbackMethod1")
	@RateLimiter(name="bService")
	public ResponseEntity<Object> getVendor(@PathVariable long id){
		return new ResponseEntity<>(busservice.getFromVendor(id),HttpStatus.OK);
	}
	
	public ResponseEntity<?> fallbackMethod1(long id,Throwable throwable) {
		System.out.println("*************************fallback**********************************************");
		return  ResponseEntity.ok().body("waitt");
	}
	
	
	
//	public ResponseEntity<?> fallback1(Throwable t)
//	{
//		return ResponseEntity.status(HttpStatus.ACCEPTED).body("Fallback response");
//				}

	@GetMapping("/bus/{id}")
	public ResponseEntity<Bus> getBus(@PathVariable long id){
		Optional<Bus> v1=busservice.findBus(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping("/bus")
	public ResponseEntity<Bus> addVendor(@RequestBody Bus v1){
		return new ResponseEntity<>(busservice.addBus(v1),HttpStatus.OK);
	}
	
	@PutMapping("/bus/{id}")
	public ResponseEntity<Bus> updateBus(@PathVariable long id,@RequestBody Bus v1){
		Optional<Bus> v=busservice.updateBus(v1, id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/bus/{id}")
	public ResponseEntity<Bus> deleteBus(@PathVariable long id){
		Optional<Bus> v=busservice.deleteBus(id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	

}
