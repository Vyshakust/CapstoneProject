package com.ust.bus.dto;

import javax.persistence.Column;

public class Vendordto {
	private long id;
	private String vendor_name;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getVendor_name() {
		return vendor_name;
	}
	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}
	
	

}
