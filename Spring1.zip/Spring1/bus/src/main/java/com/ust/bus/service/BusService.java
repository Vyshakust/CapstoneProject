package com.ust.bus.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ust.bus.dto.Vendordto;
import com.ust.bus.model.Bus;
import com.ust.bus.repository.BusInterface;


@Service
public class BusService {
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private BusInterface busrepo;
	
	public Object getFromVendor (long id) {
		Optional<Bus> b1=busrepo.findById(id);
		
		String url = "http://localhost:8084/vendors/"+b1.get().getVendorid();
//		ResponseEntity<Vendordto> response = restTemplate.getForEntity(url, Vendordto.class);
		ResponseEntity response = restTemplate.getForEntity(url, String.class);
//		Vendordto vendor=restTemplate.getForObject(url,Vendordto.class,id);
//		return vendor;
		if (response.getStatusCode() == HttpStatus.OK) {
	        return response.getBody();
	        } else {
	        // Handle error case
	        return null;
	    }
	}
	
	public List<Bus> getAllBus(){
		return busrepo.findAll();
	}
	
	public Optional<Bus> findBus(long id){
		Optional<Bus> v1=busrepo.findById(id);
		return v1;
	}
	
	public Bus addBus(Bus v) {
		Bus v1 = busrepo.save(v);
		return v1;
	}
	
	public Optional<Bus> updateBus(Bus v,long id) {
		Optional<Bus> v1=busrepo.findById(id);
		if(v1.isPresent()) {
			v1.get().setRoute(v.getRoute());
			v1.get().setArrivalTime(v.getArrivalTime());
			v1.get().setDepartureTime(v.getDepartureTime());
			v1.get().setDuration(v.getDuration());
			v1.get().setVendorid(v.getVendorid());
			busrepo.save(v1.get());
			return v1;
		}
		else {
			return v1;
		}
	}
	
	public Optional<Bus> deleteBus(long id){
		Optional<Bus> v1=busrepo.findById(id);
		if(v1.isPresent()) {
		busrepo.delete(v1.get());
		return v1;
		}
		else {
			return v1;
		}
		
	}

}
