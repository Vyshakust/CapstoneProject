package demo1;
import java.util.*;

public class First {
	public static void main(String args[] ){
		Scanner sc = new Scanner(System.in);
		int a= sc.nextInt();
		int temp =0;
		int r=0;
		while(a>0) {
			r=a%10;
			a=a/10;
			temp=temp*10+r;
		}
		System.out.println(temp);
		
	}
}
