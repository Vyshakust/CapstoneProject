package com.example.demo1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="task")
public class Task {
	@Id
	@Column(name="task_id")
	private int id;
	
	@Column(name="task_name")
	private String taskname;
	
	@Column(name="task_status")
	private String status;
	
	@Column(name="task_comments")
	private String comments;
	
	@Column(name="task_user")
	private String user;
	
	
	
	

	
}
