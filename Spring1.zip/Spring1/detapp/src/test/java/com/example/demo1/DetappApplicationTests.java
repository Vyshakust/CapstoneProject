package com.example.demo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DetappApplicationTests {

	@Test
	void contextLoads() {
	}

}
