package classes;

public class GroceriesShop {
	public GroceriesShop () {
		System.out.println("This is Groceries shop");
	}
	
	public void buyGroc() {
		System.out.println("Bought Groceries");
	}
}
