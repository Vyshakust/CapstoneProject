package classes;

public class Resturant {
	GroceriesShop gopalgrocery;
	VegetableShop ramanvegetable;
	
	public  Resturant(GroceriesShop g,VegetableShop v) {
		gopalgrocery =g;
		ramanvegetable=v;
	}
	
	public void prepareMeal() {
		gopalgrocery.buyGroc();
		ramanvegetable.buyVeg();
		System.out.println("Meals prepared");
	}
	
	public void servemeal() {
		prepareMeal();
		System.out.println("Meals Served");
	}
}
