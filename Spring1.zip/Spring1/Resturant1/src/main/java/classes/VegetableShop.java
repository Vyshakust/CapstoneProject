package classes;

public class VegetableShop {
	public VegetableShop(){
		System.out.println("This is vegetable shop");
	}
	
	public void buyVeg(){
		System.out.println("Bought vegetables");
	}
	
}
