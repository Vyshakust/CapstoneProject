package First;

import java.io.*;
import java.util.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class FileManager 
{
   static public File createFile()
   {
       //DO NOT CHANGE THE BELOW LINE
	   
	     File file=new File("C:\\Users\\235794\\visitors1.txt");
	     try {
	     file.createNewFile();
	     }
	     catch(Exception e) {
	    	 System.out.println(e);
	     }
       return file;//change the return type as per the requirement    
   }
   static public void writeFile(File f, String record)
	{
	    try{ 
          //CODE HERE
	    	FileWriter fstream = new FileWriter("C:\\\\Users\\\\235794\\\\visitors1.txt",true);
	  	  BufferedWriter out = new BufferedWriter(fstream);
	  	  out.write(record);
	  	  out.close();
	    }
	    catch(Exception e){
	        System.out.println(e.getMessage());
	    }
	} 
	static public String[] readFile(File f)	{
	    try {
         //CODE HERE
	    String str="";
	    FileInputStream fin=new FileInputStream("C:\\Users\\235794\\visitors1.txt");
	    int i=0;
	    while((i=fin.read())!=-1) {
	    	str=str+(char)i;
	    }
	    fin.close();
	    
	    
	    
	    String strArray[] = str.split(" ");
	    return strArray;
	    
       } catch (FileNotFoundException e) {
           System.out.println("Unable to find the file: fileName");
       } catch (IOException e) {
           System.out.println("Unable to read the file: fileName");
       }
       return null;
	}
}
