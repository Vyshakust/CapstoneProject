package File1;

import java.io.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;
class Student implements Serializable{
	public int rollno;
	public String name;
	public Student(int rollno,String name) {
		this.rollno=rollno;
		this.name=name;
	}
	
}

public class Serialization1 {
	public static void main(String args[]) {
		try {
		File f1 = new File("C:\\Users\\235794\\serializationfile.txt");
		f1.createNewFile();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		Student obj = new Student(20,"vyshak");
		
		try {
			FileOutputStream fout = new FileOutputStream("C:\\Users\\235794\\serializationfile.txt");
			ObjectOutputStream out = new ObjectOutputStream(fout);
			out.writeObject(obj);
			out.flush();
			out.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		try {
			FileInputStream fin = new FileInputStream("C:\\Users\\235794\\serializationfile.txt");
			ObjectInputStream in = new ObjectInputStream(fin);
			Student s=(Student)in.readObject();
			System.out.print(s.name);
			in.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
	}

}
