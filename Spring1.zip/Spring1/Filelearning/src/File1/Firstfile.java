package File1;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

public class Firstfile {
	public static void main(String args[]) {
		File f = new File("C:\\Users\\235794\\firstfile.txt");
		try {
		f.createNewFile();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		String s="vyshak how are you";
		try {
		FileWriter fw = new FileWriter("C:\\Users\\235794\\firstfile.txt");
		fw.write(s);
		fw.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		String str="";
		try {
			FileReader fr = new FileReader("C:\\Users\\235794\\firstfile.txt");
			int i=0;
			while((i=fr.read())!=-1) {
				str=str+(char)i;
			};
			System.out.println(str);
			fr.close();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
	}
}
