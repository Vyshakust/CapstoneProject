package com.ust.restlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestLearnApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestLearnApplication.class, args);
	}

}
