package com.ust.training;
public class VegetableShop {
	
	public VegetableShop() {
		
		System.out.println("inside default constructor of VegetableShop");
	}
	
public void supplyVegetables() {
		
		System.out.println("Vegetables supplied");
	}

}
