package com.feign.employee.Department;

import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "Organisation-service",fallback = Organisation.class)
@EnableCircuitBreaker
public interface OrganisationClient {
	
	    @GetMapping("/organisation/{id}")
	    ResponseEntity<?> getOrganisationById(@PathVariable("id") Long id);
	    
	   

}
