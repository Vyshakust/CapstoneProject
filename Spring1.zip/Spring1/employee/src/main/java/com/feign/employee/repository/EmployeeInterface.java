package com.feign.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.feign.employee.model.Employee;

@Repository
public interface EmployeeInterface extends JpaRepository<Employee,Long> {

}
