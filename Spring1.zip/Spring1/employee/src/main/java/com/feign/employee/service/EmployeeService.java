package com.feign.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.feign.employee.Department.Organisation;
import com.feign.employee.Department.OrganisationClient;
import com.feign.employee.model.Employee;
import com.feign.employee.repository.EmployeeInterface;



@Service
public class EmployeeService {
	
	@Autowired
	EmployeeInterface emprepo;
	
	private final OrganisationClient orgclient;

    public EmployeeService(OrganisationClient organisationclient) {
        this.orgclient = organisationclient;
    }
	
	
    public Object getEmployeeOrganisation(Long employeeId) {
       
        Optional<Employee> employee = emprepo.findById(employeeId);

        
        ResponseEntity<?> orgn= orgclient.getOrganisationById(employee.get().getOrganisationId());

        return orgn.getBody();
 }
	
	public List<Employee> getAllEmployee(){
		return emprepo.findAll();
	}
	
	public Optional<Employee> findEmployee(long id){
		Optional<Employee> v1=emprepo.findById(id);
		return v1;
	}
	
	public Employee addEmployee(Employee v) {
		Employee v1 = emprepo.save(v);
		return v1;
	}
	
	public Optional<Employee> updateEmployee(Employee v,long id) {
		Optional<Employee> v1=emprepo.findById(id);
		if(v1.isPresent()) {
			v1.get().setEmployeeName(v.getEmployeeName());
			return v1;
		}
		else {
			return v1;
		}
	}
	
	public Optional<Employee> deleteEmployee(long id){
		Optional<Employee> v1=emprepo.findById(id);
		if(v1.isPresent()) {
			emprepo.delete(v1.get());
		return v1;
		}
		else {
			return v1;
		}
		
	}

}
