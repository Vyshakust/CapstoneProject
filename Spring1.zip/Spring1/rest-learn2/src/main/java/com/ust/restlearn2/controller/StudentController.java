package com.ust.restlearn2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.restlearn2.model.Student;
import com.ust.restlearn2.service.StudentService;

@RestController
public class StudentController {
	
	
	@Autowired
	StudentService studentservice;
	
	@GetMapping("/students")
	public List<Student> getAllStudents(){
		return studentservice.getAllStudents();
	}
	
	@GetMapping("/students/{id}")
	public Student getStudentById(@PathVariable String id){
		return studentservice.getStudentById(id);
	}
	
	@PostMapping("/students")
	public void createStudent(@RequestBody Student student) {
		studentservice.addCountry(student);
	}
	
	@PutMapping("/students/{id}")
	public void updateStudent(@PathVariable String id,@RequestBody Student stud) {
		studentservice.updateStudent(id,stud.getName());
	}
	
	@DeleteMapping("/students/{id}")
	public void deleteById(@PathVariable String id) {
		studentservice.deleteById(id);
	}
	
	

}
