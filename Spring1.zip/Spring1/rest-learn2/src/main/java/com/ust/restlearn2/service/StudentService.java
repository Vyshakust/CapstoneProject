package com.ust.restlearn2.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.restlearn2.model.Student;
import com.ust.restlearn2.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired 
	StudentRepository studentrepo;
	
	@Transactional
	public List<Student> getAllStudents(){
		return studentrepo.findAll();
	}
	
	@Transactional
	public Student getStudentById(String id) {
		//Optional<Student> stud =studentrepo.findById(id);
		Student s = studentrepo.findById(id).orElseThrow(()->new NoSuchElementException("jhg"));
		return s;
		//return stud.get();
	}
	
	@Transactional
	public void addCountry(Student student) {
		studentrepo.save(student);
	}
	
	@Transactional
	public void updateStudent(String id, String name) {
		Optional<Student> stud=studentrepo.findById(id);
		Student studnew=stud.get();
		studnew.setName(name);
		studentrepo.save(studnew);
	}
	
	@Transactional
	public void deleteById(String id) {
		studentrepo.deleteById(id);
	}
}
