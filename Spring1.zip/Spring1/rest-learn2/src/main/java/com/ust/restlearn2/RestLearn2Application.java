package com.ust.restlearn2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestLearn2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestLearn2Application.class, args);
	}

}
