package com.exam.practise2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.practise2.entity.Book;
import com.exam.practise2.entity.Student;
import com.exam.practise2.repository.BookRepository;
import com.exam.practise2.repository.StudentRepository;

@RestController
public class LibraryController {
	
	@Autowired
	BookRepository bookrepo;
	
	@Autowired
	StudentRepository studentrepo;
	
	@GetMapping("/students")
	public ResponseEntity<List<Student>> getAllStudents(){
		return new ResponseEntity<>(studentrepo.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/books")
	public ResponseEntity<List<Book>> getAllBooks(){
		return new ResponseEntity<>(bookrepo.findAll(),HttpStatus.OK);
	}
	
	@PostMapping("/students")
	public ResponseEntity<Student> addStudent(@RequestBody Student student){
		Student s1=studentrepo.save(student);
		return new ResponseEntity<>(s1,HttpStatus.CREATED);
	}
	
	@PostMapping("/books")
	public ResponseEntity<Book> addBook(@RequestBody Book book){
		Book b1=bookrepo.save(book);
		return new ResponseEntity<>(b1,HttpStatus.CREATED);
	}

}
