package com.examfeign.feignStudent.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.examfeign.feignStudent.Teacher.TeacherClient;
import com.examfeign.feignStudent.model.Student;
import com.examfeign.feignStudent.repository.Studentrepo;


@Service
public class StudentService {
	@Autowired
	Studentrepo studrepo;
	
	@Autowired
	TeacherClient teachclient;
	public  Object getStudentTeacher(long id) {
		 Optional<Student> stud = studrepo.findById(id);

	        
	        ResponseEntity<?> orgn= teachclient.getTeacherById(stud.get().getTech());

	        return orgn.getBody();
	}

}
