package com.examfeign.feignStudent.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@Column(name="stu_id")
	private long id;
	
	@Column(name="stu_name")
	private String name;
	
	@Column(name="stu_teach")
	private long tech;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getTech() {
		return tech;
	}

	public void setTech(long tech) {
		this.tech = tech;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", tech=" + tech + "]";
	}
	
	

}
