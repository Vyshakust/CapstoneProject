package com.examfeign.feignStudent.Teacher;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



@FeignClient(name = "Teacher-service")
public interface TeacherClient {
	
	 @GetMapping("/organisation/{id}")
	  ResponseEntity<?> getTeacherById(@PathVariable("id") Long id);

}
