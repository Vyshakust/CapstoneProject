package com.examfeign.feignStudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
