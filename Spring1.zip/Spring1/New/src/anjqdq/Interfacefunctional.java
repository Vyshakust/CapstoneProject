package anjqdq;

public class Interfacefunctional {

}
