package com.ust.restlearn4.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.restlearn4.model.Book;
import com.ust.restlearn4.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	BookRepository bookrepo;
	
	@Transactional
	public List<Book> getAllBooks(){
		return bookrepo.findAll();
	}

	
	@Transactional
	public Book getBook(int id) {
		Optional<Book> c1=bookrepo.findById(id);
		Book c2=c1.get();
		return c2;
	}

	@Transactional
	public void addNewBook(Book c2) {
		Book c1= new Book();
		c1=(Book)c2;
		bookrepo.save(c1);
	}

	@Transactional
	public void deleteBook(int id) {
		// TODO Auto-generated method stub
		bookrepo.deleteById(id);
	}
	
	@Transactional
	public void updateBook(Book c1) {
		Optional<Book> c2=bookrepo.findById(c1.getBookId());
		Book c3 = c2.get();
		c3.setBookName(c1.getBookName());
		c3.setAuthorName(c1.getAuthorName());
		c3.setBookPrice(c1.getBookPrice());
		bookrepo.save(c3);
	}
}
