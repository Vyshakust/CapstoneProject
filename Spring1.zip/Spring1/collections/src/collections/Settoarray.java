package collections;
import java.util.*;
import java.util.stream.*;

public class Settoarray {
	public static void main(String args[] ){
		int arr [] = {1,2,5,6,7,3,3,2,7,5,6};
		 List<Integer> list = new ArrayList<>();
		 for(int a:arr) {
			 list.add(a);
		 }
		 Set<Integer> set1=new LinkedHashSet<>(list);
		 int k=0;
		 for(Integer a:set1) {
			 arr[k]=a;
			 k++;
		 }
	}
}
