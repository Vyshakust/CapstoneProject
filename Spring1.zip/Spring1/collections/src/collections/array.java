package collections;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.*;
public class array {
	public static void main(String args[]) {
	int arr[]= {2,3,2,5,3,7,4,6,7,8};
	int arr1[]=new int[arr.length];
	Set<Integer> lset=new LinkedHashSet<>();
	for(int a:arr) {
		lset.add(a);
	}
	int index=0;
	for(Integer a:lset) {
		arr1[index]=a;
		index++;
	}

	arr=Arrays.copyOf(arr1, lset.size());
	for(int i=0;i<arr.length;i++) {
	System.out.println(arr[i]);
	}
}
}
