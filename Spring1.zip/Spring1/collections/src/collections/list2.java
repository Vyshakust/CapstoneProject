package collections;
import java.util.*;

public class list2 {
	public static void main(String args[]) {
		String str;
		str="Hello";
		String arr[]=null;
		arr=str.split(" ");
		List<String> list = new ArrayList<>();
		list=Arrays.asList(arr);
		System.out.println(list);
	}

}
