package collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

@FunctionalInterface
interface Newmethod{
    public Product find(List<Product> list);
    
}

public class list1 {
    public static void main(String[] args) {
		List<Product> list = new ArrayList<Product>();
		list.add(new Product(12,"Baby Oil","Baby",800.00));
		list.add(new Product(3,"Baby Cream","Baby",600.00));
		list.add(new Product(10,"Baby Powder","Baby",1000.00));
		list.add(new Product(7,"Baby dress","Baby",1500.00));
		list.add(new Product(5,"Rattle","Toy",300.00));
		list.add(new Product(2,"Duckling set","Toy",700.00));
		list.add(new Product(6,"Bath toys","Toy",500.00));
		list.add(new Product(1,"Jumping Monkeys","Toy",1200.00));
		
		Newmethod m=(list<Product> list1)->{
		    
		  
		  for(int k=0;k<list1.size();k++){
		    
		    if(list1.get(k).getName().substring(0,4)!="Baby"){
		        list1.remove(k);
		    }
		  }
		  System.out.println(list);
		  
		   // Product min=list1.get(0);
		  //  for(int i=0;i<list1.size();i++){
		  //      for(int j=i+1;j<list1.size();j++){
		  //          if(list1.get(i).getPrice()>list1.get(j).getPrice()){
		  //              min=list1.get(j);
		  //          }
		  //      }
		        
		  //  }
		    //return min;
		};
		
		//System.out.print(m.find(list).getId()+" ");
    	
	}
    
//}



class Product 
{
	private int id;
	private String name;
	private String category;
	private Double price;
		
	public Product(int id, String name, String category, Double price) {
		this.id = id;
		this.name = name;
		this.category = category;
		this.price = price;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
}
