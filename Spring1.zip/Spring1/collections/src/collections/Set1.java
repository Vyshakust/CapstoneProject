package collections;

import java.util.*;

class Student {
	private int id;
	private String name;
	public Student(int id,String name) {
		this.id=id;
		this.name=name;
	}

}

public class Set1{
	public static void main(String args[]) {
		Set<Student> set1= new HashSet<Student>();
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<3;i++) {
			Student ob = new Student(sc.nextInt(),sc.nextLine());
			set1.add(ob);
		}
		for(int i=0;i<3;i++) {
			System.out.println(set1.get(i));
			
		}
	}
}