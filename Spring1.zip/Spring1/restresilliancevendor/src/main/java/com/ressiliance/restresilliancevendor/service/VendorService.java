package com.ressiliance.restresilliancevendor.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ressiliance.restresilliancevendor.model.Vendor;
import com.ressiliance.restresilliancevendor.repo.VendorRepository;



@Service
public class VendorService {
	@Autowired
	VendorRepository vendorrepo;
	
	public List<Vendor> getAllVendors(){
		return vendorrepo.findAll();
	}
	
	public Optional<Vendor> findVendor(long id){
		Optional<Vendor> v1=vendorrepo.findById(id);
		return v1;
	}
	
	public Vendor addVendor(Vendor v) {
		Vendor v1 = vendorrepo.save(v);
		return v1;
	}

}
