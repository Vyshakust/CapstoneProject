package com.ressiliance.restresilliancevendor.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ressiliance.restresilliancevendor.model.Vendor;
import com.ressiliance.restresilliancevendor.service.VendorService;


@RestController
public class VendorController {
	
	@Autowired
	VendorService vendorservice;
	
	@GetMapping("/vendors")
	public ResponseEntity<List<Vendor>> getAllVendors(){
		return new ResponseEntity<>(vendorservice.getAllVendors(),HttpStatus.OK);
	}

	@GetMapping("/vendors/{id}")
	public ResponseEntity<Vendor> getVendors(@PathVariable long id){
		Optional<Vendor> v1=vendorservice.findVendor(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping("/vendors")
	public ResponseEntity<Vendor> addVendor(@RequestBody Vendor v1){
		return new ResponseEntity<>(vendorservice.addVendor(v1),HttpStatus.OK);
	}

}
