package com.ressiliance.restresilliancevendor.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Vendor {
	
	@Id
	@Column(name="vendor_id")
	private long id;
	
	@Column(name="vendor_name")
	private String vendor_name;

	public long getId() {
		return id;
	}

	public String getVendor_name() {
		return vendor_name;
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Vendor [id=" + id + ", vendor_name=" + vendor_name + "]";
	}
	
	

}
