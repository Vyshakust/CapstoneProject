package com.ressiliance.restresilliancevendor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestresilliancevendorApplicationTests {

	@Test
	void contextLoads() {
	}

}
