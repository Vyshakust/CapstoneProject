package com.ust.restlearn3.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.restlearn3.model.Event;
import com.ust.restlearn3.repository.EventRepository;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    // methods for admin actions

    public List<Event> getAllEventsByAdmin() {
        return eventRepository.findByIsAdmin(true);
    }

    public Event getEventByIdForAdmin(int id) {
        return eventRepository.findByIdAndIsAdmin(id, true)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", id));
    }

    public Event createEventByAdmin(Event event) {
        event.setIsAdmin(true);
        return eventRepository.save(event);
    }

    public Event updateEventByAdmin(int id, Event eventDetails) {
        Event event = eventRepository.findByIdAndIsAdmin(id, true)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", id));

        event.setName(eventDetails.getName());
        event.setDate(eventDetails.getDate());
        event.setStatus(eventDetails.getStatus());
        event.setComments(eventDetails.getComments());

        return eventRepository.save(event);
    }

    public void deleteEventByAdmin(Long id) {
        Event event = eventRepository.findByIdAndIsAdmin(id, true)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", id));

        eventRepository.delete(event);
    }

    // methods for user actions

    public List<Event> getAllEventsByUser() {
        return eventRepository.findByIsAdmin(false);
    }

    public Event getEventByIdForUser(Long id) {
        return eventRepository.findByIdAndIsAdmin(id, false)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", id));
    }

    public Event updateEventByUser(Long id, String status, String comments) {
        Event event = eventRepository.findByIdAndIsAdmin(id, false)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", id));

        event.setStatus(status);
        event.setComments(comments);

        return eventRepository.save(event);
    }
}
