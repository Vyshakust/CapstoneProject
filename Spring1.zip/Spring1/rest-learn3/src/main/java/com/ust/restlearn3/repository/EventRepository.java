package com.ust.restlearn3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ust.restlearn3.model.Event;

@Repository
public interface EventRepository extends JpaRepository<Event, Integer> {
	@Query("SELECT e FROM Event e WHERE e.b = :b")
	List<Event> findByIsAdmin(@Param("b") boolean b);

	@Query("SELECT e FROM Event e WHERE e.id = :id AND e.b = :b")
	Object findByIdAndIsAdmin(@Param("id") int id,@Param("b") boolean b);
	

}
