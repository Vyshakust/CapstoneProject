package com.ust.restlearn3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestLearn3Application {

	public static void main(String[] args) {
		SpringApplication.run(RestLearn3Application.class, args);
	}

}
