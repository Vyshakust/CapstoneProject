package sampleproject2;

public class Resturant {
	public Resturant() {
		System.out.println("New Resturant");
	}
	
	public void servefood() {
		System.out.println("Food Served");
	}
}
