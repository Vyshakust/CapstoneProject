package com.ust.self1security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
//@EnableWebSecurity
public class Self1securityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Self1securityApplication.class, args);
	}

}
