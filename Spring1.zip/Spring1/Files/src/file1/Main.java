package file1;

import java.util.*;
import java.io.*;
 @SuppressWarnings("unchecked")//Do not delete this line
public class Main
{
	public static void main(String args[]) 
	{   
		
	    File f = FileManager.createFile();
	    Scanner sc = new Scanner(System.in);
        String ans="no";
	    do{
	    System.out.println("Enter Name");
	    System.out.println("Enter Phone Number");
	    System.out.println("Enter Email");
	        //CODE HERE
	  
	    String record = "";
	    record=sc.nextLine();
	    record=record+",";
	    record=record+sc.nextLine();
	    record=record+",";
	    record=record+sc.nextLine();
	    record=record+";";
	    FileManager.writeFile(f,record);
	    System.out.println("Do you want to enter another record(yes/no)");
	    ans = sc.nextLine();
	    }
	    while(ans.equalsIgnoreCase("yes"));
	    
	    String[] s = FileManager.readFile(f);
	    for(int i=0;i<s.length;i++){
	           System.out.println(s);
	    	
	    }
	    sc.close();
	}
    
}
