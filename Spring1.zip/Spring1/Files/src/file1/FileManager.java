package file1;

import java.io.*;
import java.util.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class FileManager 
{
   static public File createFile()
   {
       //DO NOT CHANGE THE BELOW LINE
	   
	     File file=new File("visitors1.txt");
	     file.createNewFile();;
       return file;//change the return type as per the requirement    
   }
   static public void writeFile(File f, String record)
	{
	    try{ 
          //CODE HERE
	    	FileOutputStream fout=new FileOutputStream("visiotrs1.txt");
	    	 byte b[]=record.getBytes();
	    	 fout.write(b);    
	         fout.close(); 
	    }
	    catch(Exception e){
	        System.out.println(e.getMessage());
	    }
	} 
	static public String[] readFile(File f)	{
	    try {
         //CODE HERE
	    String str="";
	    FileInputStream fin=new FileInputStream("visiotrs1.txt");
	    int i=0;
	    while((i=fin.read())!=-1) {
	    	str=str+(char)i;
	    }
	    fin.close();
	    	 
	    }
	    	
       } catch (FileNotFoundException e) {
           System.out.println("Unable to find the file: fileName");
       } catch (IOException e) {
           System.out.println("Unable to read the file: fileName");
       }
       return null;
	}
}
