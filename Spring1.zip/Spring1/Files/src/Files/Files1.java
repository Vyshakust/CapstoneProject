package Files;

public class Files1 {
	public static void main(String args[]) {
		File f = new File("C:\\Users\\235794\\file1");
		
	}

}
