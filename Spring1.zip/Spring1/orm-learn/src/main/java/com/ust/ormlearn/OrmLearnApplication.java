package com.ust.ormlearn;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.ust.ormlearn.model.Country;
import com.ust.ormlearn.service.CountryService;

@SpringBootApplication
public class OrmLearnApplication {
	
	private static CountryService countryservice;
	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args); 
		countryservice = context.getBean(CountryService.class); 
		 
		//testGetCountryByCode("IN");
		//testAddCountry();
		//testUpdateCountry("IN","Indiana");
		testDeleteCountry("IN");
		testGetAllCountries();

	}
		
		private static void testGetAllCountries() {
			List<Country> countries=countryservice.getAllCountries();
			for(Country co:countries) {
				System.out.println(co.getName());
			}
		}
		
		private static void testGetCountryByCode(String code) {
			Country country =countryservice.getCountryByCode(code);
			System.out.println(country.getName());
		}
		
		private static void testAddCountry() {
			Country country1 = new Country();
			countryservice.addCountry(country1);
		}
		
		private static void testUpdateCountry(String code,String name) {
			countryservice.updateCountry(code, name);
		}
		
		private static void testDeleteCountry(String code) {
			countryservice.deleteCountry(code);
		}
		
	

}
