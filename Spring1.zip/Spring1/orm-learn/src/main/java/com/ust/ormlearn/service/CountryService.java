package com.ust.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.ormlearn.model.Country;
import com.ust.ormlearn.repository.CountryRepository;



@Service
public class CountryService {
	@Autowired
	private CountryRepository countryrepo;
	
	
	
	@Transactional
	public List<Country> getAllCountries(){
		return countryrepo.findAll();
	}
	
	@Transactional
	public Country getCountryByCode(String code) {
		Optional<Country> result = countryrepo.findById(code); 
		Country country=result.get();
		return country;
	}
	
	@Transactional
	public void addCountry(Country country2) {
		
		country2.setCode("JP");
		country2.setName("Japan");
		countryrepo.save(country2);
	}
	
	@Transactional
	public void updateCountry(String code,String name) {
		Optional<Country> result = countryrepo.findById(code);
		Country country=result.get();
		country.setName(name);
		countryrepo.save(country);
	}
	
	@Transactional
	public void deleteCountry(String code) {
		countryrepo.deleteById(code);
	}

}
