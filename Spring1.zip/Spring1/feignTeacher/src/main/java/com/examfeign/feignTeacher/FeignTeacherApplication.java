package com.examfeign.feignTeacher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignTeacherApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeignTeacherApplication.class, args);
	}

}
