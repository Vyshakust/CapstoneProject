package com.examfeign.feignTeacher.repos;

public interface Teacherepo {

}
