package com.examfeign.feignTeacher.model;

@Entity
public class Teacher {

}
