package com.examfeign.feignTeacher.controller;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



public class TeacherController {

	@GetMapping("/teacher/{id}")
	public ResponseEntity<Organisation> getVendors(@PathVariable long id){
		Optional<Organisation> v1=organisationservice.findVendor(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
}
