package com.examfeign.feignTeacher.service;

public class TeacherService {

}
