package comparator1;
import java.util.*;

class Students{
	private int rollno;
	private String name;
	
	public void setRollNo(int rollno) {
		this.rollno=rollno;
	}
	
	public int getRollNo() {
		return this.rollno;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	public String getName() {
		return this.name;
	}
}

class Rollcompare implements Comparator<Students>{
	
	public int compare(Students obj1,Students obj2) {
		return obj1.getRollNo()-obj2.getRollNo();
	}
}

class Namecompare implements Comparator<Students>{
	public int compare(Students obj1,Students obj2) {
		return obj1.getName().compareTo(obj2.getName());
	}
}


public class Student {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of students");
		int n=sc.nextInt();
		
		List<Students> stlist = new ArrayList<>();
		for(int i=0;i<n;i++) {
			Students obj = new Students();
			System.out.println("Enter Student roll no");
			obj.setRollNo(sc.nextInt()) ;
			sc.nextLine();
			System.out.println("Enter Student name");
			obj.setName(sc.nextLine());
			stlist.add(obj);			
		}
		//Collections.sort(stlist,new Rollcompare());
		Collections.sort(stlist,new Namecompare());
		for(Students s:stlist) {
		System.out.println(s.getRollNo()+" "+s.getName());
		}
	}
}
