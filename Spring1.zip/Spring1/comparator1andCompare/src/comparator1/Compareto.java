package comparator1;
import java.util.*;
import java.io.*;
class Students1 implements Comparable<Students1>{
	String name;
	public void setName(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
	
	public int compareTo(Students1 obj) {
		return this.name.compareTo(obj.name);
	}
}

public class Compareto {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of students");
		int n=sc.nextInt();
		sc.nextLine();
		List<Students1> stlist = new ArrayList<>();
		for(int i=0;i<n;i++) {
			Students1 obj = new Students1();
			System.out.println("Enter Student name");
			obj.setName(sc.nextLine());
			stlist.add(obj);			
		}
		Collections.sort(stlist);
		for(Students1 x:stlist) {
			System.out.println(x.getName());
		}
	}

}

//import java.util.*;  
//import java.io.*;  
//class Student implements Comparable<Student>{  
//int rollno;  
//String name;  
//int age;  
//Student(int rollno,String name,int age){  
//this.rollno=rollno;  
//this.name=name;  
//this.age=age;  
//}  
//public int compareTo(Student st){  
//if(age==st.age)  
//return 0;  
//else if(age > st.age)  
//return 1;  
//else  
//return -1;  
//}  
//}  
////Creating a test class to sort the elements  
//public class Compareto{  
//public static void main(String args[]){  
//ArrayList<Student> al=new ArrayList<Student>();  
//al.add(new Student(101,"Vijay",23));  
//al.add(new Student(106,"Ajay",27));  
//al.add(new Student(105,"Jai",21));  
//  
//Collections.sort(al);  
//for(Student st:al){  
//System.out.println(st.rollno+" "+st.name+" "+st.age);  
//}  
//}  
//}  
