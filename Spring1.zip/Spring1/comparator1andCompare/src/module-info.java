module comparator1 {
}