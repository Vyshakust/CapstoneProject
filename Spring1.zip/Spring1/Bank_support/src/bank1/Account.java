package bank1;
import java.util.*;
public class Account {
	private  int accountNumber;
	private String accountHolderName;
	private float balance=10000;

	public void createAccount(String name,int number) {
		accountNumber=number;
		accountHolderName=name;
	}
	
	 public void updateAccount(String name,int number) {
		accountNumber=number;
		accountHolderName=name;
		System.out.println("accountNumber is"+accountNumber +", accountName is "+accountHolderName);
	}

	 public  void withdrawMoney(float amountToWithdraw) {
		 if(balance<amountToWithdraw) {
			 System.out.println("Insufficient Balance");
		 }
		 else {
			 balance =balance-amountToWithdraw;
			 System.out.println("Remaining balance ="+balance);
		 }
}

	 public void depositMoney(float amountToAdd) {
		 balance=balance+amountToAdd;
		 System.out.print("Remaining balance ="+balance);
		 
	 }

public float getBalance() {
	return balance;
}
public void showBalance() {
	System.out.println( balance);
}
	
}
