package bank1;
import java.util.*;
public class FDAccount extends Account implements Renewable{
	int tenure;
	boolean autoRenewal;
	int maturityDate;
	int currentDate;
	FDAccount(){
	System.out.println("input tenure autoRenewal maturityDate currentDate");
	}
	public static  void interest(float p,float n) {
		
		InterestCalculator in= new InterestCalculator();
		System.out.println(in.calculateInterest(p, n, 7));
	}
	public  void autoRenewal(int tenure) {
		if(autoRenewal==true) {
			if(maturityDate<=currentDate) {
				maturityDate=currentDate+tenure;
			}
			
		}
		
	}
}
