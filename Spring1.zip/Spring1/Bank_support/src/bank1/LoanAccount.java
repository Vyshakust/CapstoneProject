package bank1;

public class LoanAccount extends Account {

	float EMI;
	float loanOutStanding;
	float tenure;
}
