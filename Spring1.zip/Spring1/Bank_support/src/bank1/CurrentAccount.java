package bank1;

public class CurrentAccount extends Account {
	int overDraftLimit;

}
