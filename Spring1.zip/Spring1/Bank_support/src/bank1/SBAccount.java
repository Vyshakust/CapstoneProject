package bank1;

public class SBAccount extends Account {
	public  void interest(float p,float n) {
		
		InterestCalculator in= new InterestCalculator();
		System.out.println(in.calculateInterest(p, n, 4));
	}
}
