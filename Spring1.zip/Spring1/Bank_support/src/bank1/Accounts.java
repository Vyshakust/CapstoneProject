package bank1;
import java.util.*;

public class Accounts {
	
	public static void main(String args[] ){
		SBAccount a1= new SBAccount();
		a1.createAccount("vyshak", 1);
		a1.interest(2, 2);
		a1.depositMoney(4000);
		a1.withdrawMoney(2000);
		a1.interest(a1.getBalance(), 2);
		a1.showBalance();
		FDAccount a2=new FDAccount();
}
}
