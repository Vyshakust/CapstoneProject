package bank1;

public interface Renewable {
	public static void autoRenewal(int tenure) {
		
	}

}
