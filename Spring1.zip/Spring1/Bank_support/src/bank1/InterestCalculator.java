package bank1;

public class InterestCalculator {
	public float calculateInterest(float p,float n,int r) {
		return (p*n*r)/100;
	}

}
