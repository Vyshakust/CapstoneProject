package com.ust.flightInfo.model;

import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table
public class Flight {

	@Id
	private String flight_no;
	private String flight_name;
	private String starting_point;
	private String end_point;
	@DateTimeFormat(pattern = "HH:mm")
	private LocalTime departure_time;
	private LocalTime arrival_time;
	public String getFlight_no() {
		return flight_no;
	}
	public void setFlight_no(String flight_no) {
		this.flight_no = flight_no;
	}
	public String getFlight_name() {
		return flight_name;
	}
	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}
	public String getStarting_point() {
		return starting_point;
	}
	public void setStarting_point(String starting_point) {
		this.starting_point = starting_point;
	}
	public String getEnd_point() {
		return end_point;
	}
	public void setEnd_point(String end_point) {
		this.end_point = end_point;
	}
	public LocalTime getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(LocalTime departure_time) {
		this.departure_time = departure_time;
	}
	public LocalTime getArrival_time() {
		return arrival_time;
	}
	public void setArrival_time(LocalTime arrival_time) {
		this.arrival_time = arrival_time;
	}
}
