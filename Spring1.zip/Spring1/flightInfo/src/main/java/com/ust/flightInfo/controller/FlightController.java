package com.ust.flightInfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.flightInfo.model.Flight;
import com.ust.flightInfo.service.FlightService;



@RestController
@RequestMapping("flight")
public class FlightController {

	@Autowired
	FlightService fService;
	
	@GetMapping("/flights")
	public ResponseEntity<List<Flight>> getAllflight(){
		return ResponseEntity.ok().body(fService.getAllflight());
	}
	@GetMapping("/flightByNum/{num}")
	public ResponseEntity<Flight> getFlightById(@PathVariable String num){
		
		if(fService.getFlightbyId(num).isPresent()) {
			return ResponseEntity.ok().body(fService.getFlightbyId(num).get());
		}
		else {
			return ResponseEntity.notFound().build();
		}
	}
	@PutMapping("/updateFlight/{num}")
	public ResponseEntity<Flight> updateTrainbyNum(@PathVariable String num, @RequestBody Flight f){
		
		//Optional<Train> tr = tService.updateByNumber(num); 
		if(fService.updateByNumber(num, f).isPresent()) {
			return ResponseEntity.ok().body(fService.updateByNumber(num, f).get());
		}
		else {
			return ResponseEntity.notFound().build();
		}
			
	}
	@DeleteMapping("/deleteFlight/{num}")
	public ResponseEntity<Flight> deleteTrainById(@PathVariable String num){
		
		if(fService.deleteByNum(num).isPresent()) {
			return ResponseEntity.ok().body(fService.deleteByNum(num).get());
		}
		else {
			return ResponseEntity.notFound().build();
		}
	}
}
