package com.ust.flightInfo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.flightInfo.model.Flight;

public interface FlightRepository extends JpaRepository<Flight, String> {

}
