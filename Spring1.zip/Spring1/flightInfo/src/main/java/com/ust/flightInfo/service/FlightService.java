package com.ust.flightInfo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.flightInfo.model.Flight;
import com.ust.flightInfo.repository.FlightRepository;

@Service
public class FlightService {

	@Autowired
	FlightRepository flightRepo;
	
	public List<Flight> getAllflight(){
		return flightRepo.findAll();
	}
	public Optional<Flight> getFlightbyId(String num){
		return flightRepo.findById(num);
	}
	public Optional<Flight> updateByNumber(String num, Flight f) {
		Optional<Flight> fl= flightRepo.findById(num);
		if(fl.isPresent()) {
			  fl.get().setFlight_name(f.getFlight_name());
			  fl.get().setStarting_point(f.getStarting_point());
			  fl.get().setEnd_point(f.getEnd_point());
			  fl.get().setDeparture_time(f.getDeparture_time());
			  fl.get().setArrival_time(f.getArrival_time());
			  flightRepo.save(fl.get());
			  return fl;
			 
		}
		else {
			return null;
		}
	}
	public Optional<Flight> deleteByNum(String num) {
		Optional<Flight> t= flightRepo.findById(num);
		if(t.isPresent()) {
			 flightRepo.deleteById(num);
			 return t;
		}
		else {
			return null;
		}
	}
}
