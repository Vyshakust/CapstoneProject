package com.feign.feignexample.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.feign.feignexample.model.Organisation;
import com.feign.feignexample.service.OrganisationService;



@RestController
public class OrganisationController {
	
	@Autowired
	OrganisationService organisationservice;
	
	@GetMapping("/organisation")
	public ResponseEntity<List<Organisation>> getAllVendors(){
		return new ResponseEntity<>(organisationservice.getAllVendors(),HttpStatus.OK);
	}

	@GetMapping("/organisation/{id}")
	public ResponseEntity<Organisation> getVendors(@PathVariable long id){
		Optional<Organisation> v1=organisationservice.findVendor(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping("/organisation")
	public ResponseEntity<Organisation> addVendor(@RequestBody Organisation v1){
		return new ResponseEntity<>(organisationservice.addVendor(v1),HttpStatus.OK);
	}
	
	@PutMapping("/organisation/{id}")
	public ResponseEntity<Organisation> updateVendor(@PathVariable long id,@RequestBody Organisation v1){
		Optional<Organisation> v=organisationservice.updateVendor(v1, id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/organisation/{id}")
	public ResponseEntity<Organisation> deleteVendor(@PathVariable long id){
		Optional<Organisation> v=organisationservice.deleteVendor(id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

}
