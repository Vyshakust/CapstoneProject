package com.feign.feignexample.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feign.feignexample.model.Organisation;
import com.feign.feignexample.repository.OrganisationRepository;


@Service
public class OrganisationService {
	
	@Autowired
	OrganisationRepository organrepo;
	
	public List<Organisation> getAllVendors(){
		return organrepo.findAll();
	}
	
	public Optional<Organisation> findVendor(long id){
		Optional<Organisation> v1=organrepo.findById(id);
		return v1;
	}
	
	public Organisation addVendor(Organisation v) {
		Organisation v1 = organrepo.save(v);
		return v1;
	}
	
	public Optional<Organisation> updateVendor(Organisation v,long id) {
		Optional<Organisation> v1=organrepo.findById(id);
		if(v1.isPresent()) {
			v1.get().setOrganisationName(v.getOrganisationName());
			return v1;
		}
		else {
			return v1;
		}
	}
	
	public Optional<Organisation> deleteVendor(long id){
		Optional<Organisation> v1=organrepo.findById(id);
		if(v1.isPresent()) {
			organrepo.delete(v1.get());
		return v1;
		}
		else {
			return v1;
		}
		
	}

}
