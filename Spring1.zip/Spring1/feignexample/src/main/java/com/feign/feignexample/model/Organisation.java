package com.feign.feignexample.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Organisation")
public class Organisation {
	
	@Id
	@Column(name="organisation_id")
	private long organisationId;
	
	@Column(name="organisation_name")
	private String organisationName;

	public long getOrganisationId() {
		return organisationId;
	}

	public void setOrganisationId(long organisationId) {
		this.organisationId = organisationId;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	@Override
	public String toString() {
		return "Organisation [organisationId=" + organisationId + ", organisationName=" + organisationName + "]";
	}

	
	

}
