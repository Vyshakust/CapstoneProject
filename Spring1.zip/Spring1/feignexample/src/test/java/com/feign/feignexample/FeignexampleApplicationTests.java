package com.feign.feignexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
